# __init__.py
from .magic_effects import MagicEffects, FireballEffect, ExplosionEffect
